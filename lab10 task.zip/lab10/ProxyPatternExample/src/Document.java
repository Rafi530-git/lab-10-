public interface Document {
    void display();
}
