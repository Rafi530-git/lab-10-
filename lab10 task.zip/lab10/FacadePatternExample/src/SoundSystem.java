public class SoundSystem {
    public void turnOn() {
        System.out.println("Sound System is turned ON.");
    }

    public void setVolume(int level) {
        System.out.println("Sound volume set to: " + level);
    }

    public void turnOff() {
        System.out.println("Sound System is turned OFF.");
    }
}
