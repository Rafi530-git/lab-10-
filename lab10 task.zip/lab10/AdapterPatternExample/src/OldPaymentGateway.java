public class OldPaymentGateway {
    public void payWithCard(double amount) {
        System.out.println("Payment of $" + amount + " processed using Old Payment Gateway.");
    }
}
